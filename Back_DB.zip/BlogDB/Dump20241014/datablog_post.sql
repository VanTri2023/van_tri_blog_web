-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: datablog
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name_Blog` varchar(255) NOT NULL,
  `name_Title` varchar(255) NOT NULL,
  `content_` text NOT NULL,
  `main_Image` varchar(255) DEFAULT NULL,
  `category_menu` varchar(255) DEFAULT NULL,
  `user_id_` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (5,'New Blog4','how to create new blog4','<h3>2. <strong>macOS:</strong></h3><ul><li><strong>Chỉnh thời gian màn hình chờ và yêu cầu đăng nhập:</strong><ol><li>Mở <strong>System Preferences</strong> (Tùy chọn hệ thống).</li><li>Chọn <strong>Battery</strong> hoặc <strong>Energy Saver</strong> (Tiết kiệm năng lượng) nếu bạn sử dụng máy MacBook, hoặc <strong>Display</strong> (Hiển thị) trên máy tính để bàn.</li><li>Chỉnh thời gian tự động tắt màn hình (có thể chọn 1 tiếng).</li><li>Tiếp theo, vào <strong>Security &amp; Privacy</strong> (Bảo mật &amp; Riêng tư).</li><li>Trong tab <strong>General</strong> (Chung), dưới mục <strong>Require password</strong>, chọn \"1 hour\" hoặc một thời gian dài hơn trước khi yêu cầu mật khẩu khi máy tính khóa.</li></ol></li></ul>','MainDashboard_For Admin.jpg','menu1',0,'2024-10-14 13:24:27'),(6,'New Blog5','how to create new blog5','<h3>2. <strong>macOS:</strong></h3><ul><li><strong>Chỉnh thời gian màn hình chờ và yêu cầu đăng nhập:</strong><ol><li>Mở <strong>System Preferences</strong> (Tùy chọn hệ thống).</li><li>Chọn <strong>Battery</strong> hoặc <strong>Energy Saver</strong> (Tiết kiệm năng lượng) nếu bạn sử dụng máy MacBook, hoặc <strong>Display</strong> (Hiển thị) trên máy tính để bàn.</li><li>Chỉnh thời gian tự động tắt màn hình (có thể chọn 1 tiếng).</li><li>Tiếp theo, vào <strong>Security &amp; Privacy</strong> (Bảo mật &amp; Riêng tư).</li><li>Trong tab <strong>General</strong> (Chung), dưới mục <strong>Require password</strong>, chọn \"1 hour\" hoặc một thời gian dài hơn trước khi yêu cầu mật khẩu khi máy tính khóa.</li></ol></li></ul>','BlogContent_Detail.jpg','menu2',0,'2024-10-14 13:24:50'),(7,'New Blog6','how to create new blog6','<h3>2. <strong>macOS:</strong></h3><ul><li><strong>Chỉnh thời gian màn hình chờ và yêu cầu đăng nhập:</strong><ol><li>Mở <strong>System Preferences</strong> (Tùy chọn hệ thống).</li><li>Chọn <strong>Battery</strong> hoặc <strong>Energy Saver</strong> (Tiết kiệm năng lượng) nếu bạn sử dụng máy MacBook, hoặc <strong>Display</strong> (Hiển thị) trên máy tính để bàn.</li><li>Chỉnh thời gian tự động tắt màn hình (có thể chọn 1 tiếng).</li><li>Tiếp theo, vào <strong>Security &amp; Privacy</strong> (Bảo mật &amp; Riêng tư).</li><li>Trong tab <strong>General</strong> (Chung), dưới mục <strong>Require password</strong>, chọn \"1 hour\" hoặc một thời gian dài hơn trước khi yêu cầu mật khẩu khi máy tính khóa.</li></ol></li></ul>','BlogContent_Detail_ForAdmin.jpg','menu2',0,'2024-10-14 13:25:14'),(8,'New Blog7','how to create new blog7','<h3>2. <strong>macOS:</strong></h3><ul><li><strong>Chỉnh thời gian màn hình chờ và yêu cầu đăng nhập:</strong><ol><li>Mở <strong>System Preferences</strong> (Tùy chọn hệ thống).</li><li>Chọn <strong>Battery</strong> hoặc <strong>Energy Saver</strong> (Tiết kiệm năng lượng) nếu bạn sử dụng máy MacBook, hoặc <strong>Display</strong> (Hiển thị) trên máy tính để bàn.</li><li>Chỉnh thời gian tự động tắt màn hình (có thể chọn 1 tiếng).</li><li>Tiếp theo, vào <strong>Security &amp; Privacy</strong> (Bảo mật &amp; Riêng tư).</li><li>Trong tab <strong>General</strong> (Chung), dưới mục <strong>Require password</strong>, chọn \"1 hour\" hoặc một thời gian dài hơn trước khi yêu cầu mật khẩu khi máy tính khóa.</li></ol></li></ul>','CreateBlogContent.jpg','menu4',0,'2024-10-14 13:25:39'),(9,'New Blog8','how to create new blog8','<h3>2. <strong>macOS:</strong></h3><ul><li><strong>Chỉnh thời gian màn hình chờ và yêu cầu đăng nhập:</strong><ol><li>Mở <strong>System Preferences</strong> (Tùy chọn hệ thống).</li><li>Chọn <strong>Battery</strong> hoặc <strong>Energy Saver</strong> (Tiết kiệm năng lượng) nếu bạn sử dụng máy MacBook, hoặc <strong>Display</strong> (Hiển thị) trên máy tính để bàn.</li><li>Chỉnh thời gian tự động tắt màn hình (có thể chọn 1 tiếng).</li><li>Tiếp theo, vào <strong>Security &amp; Privacy</strong> (Bảo mật &amp; Riêng tư).</li><li>Trong tab <strong>General</strong> (Chung), dưới mục <strong>Require password</strong>, chọn \"1 hour\" hoặc một thời gian dài hơn trước khi yêu cầu mật khẩu khi máy tính khóa.</li></ol></li></ul>','MainDashboard_General User.jpg','menu2',0,'2024-10-14 13:25:57'),(10,'New Blog9','how to create new blog9','<h3>2. <strong>macOS:</strong></h3><ul><li><strong>Chỉnh thời gian màn hình chờ và yêu cầu đăng nhập:</strong><ol><li>Mở <strong>System Preferences</strong> (Tùy chọn hệ thống).</li><li>Chọn <strong>Battery</strong> hoặc <strong>Energy Saver</strong> (Tiết kiệm năng lượng) nếu bạn sử dụng máy MacBook, hoặc <strong>Display</strong> (Hiển thị) trên máy tính để bàn.</li><li>Chỉnh thời gian tự động tắt màn hình (có thể chọn 1 tiếng).</li><li>Tiếp theo, vào <strong>Security &amp; Privacy</strong> (Bảo mật &amp; Riêng tư).</li><li>Trong tab <strong>General</strong> (Chung), dưới mục <strong>Require password</strong>, chọn \"1 hour\" hoặc một thời gian dài hơn trước khi yêu cầu mật khẩu khi máy tính khóa.</li></ol></li></ul>','MainDashboard_General User.jpg','menu1',0,'2024-10-14 13:26:17'),(11,'New Blog10','how to create new blog10','<h3>2. <strong>macOS:</strong></h3><ul><li><strong>Chỉnh thời gian màn hình chờ và yêu cầu đăng nhập:</strong><ol><li>Mở <strong>System Preferences</strong> (Tùy chọn hệ thống).</li><li>Chọn <strong>Battery</strong> hoặc <strong>Energy Saver</strong> (Tiết kiệm năng lượng) nếu bạn sử dụng máy MacBook, hoặc <strong>Display</strong> (Hiển thị) trên máy tính để bàn.</li><li>Chỉnh thời gian tự động tắt màn hình (có thể chọn 1 tiếng).</li><li>Tiếp theo, vào <strong>Security &amp; Privacy</strong> (Bảo mật &amp; Riêng tư).</li><li>Trong tab <strong>General</strong> (Chung), dưới mục <strong>Require password</strong>, chọn \"1 hour\" hoặc một thời gian dài hơn trước khi yêu cầu mật khẩu khi máy tính khóa.</li></ol></li></ul>','CreateBlogContent.jpg','menu1',0,'2024-10-14 13:26:36'),(12,'New Blog11','how to create new blog11','<h3>2. <strong>macOS:</strong></h3><ul><li><strong>Chỉnh thời gian màn hình chờ và yêu cầu đăng nhập:</strong><ol><li>Mở <strong>System Preferences</strong> (Tùy chọn hệ thống).</li><li>Chọn <strong>Battery</strong> hoặc <strong>Energy Saver</strong> (Tiết kiệm năng lượng) nếu bạn sử dụng máy MacBook, hoặc <strong>Display</strong> (Hiển thị) trên máy tính để bàn.</li><li>Chỉnh thời gian tự động tắt màn hình (có thể chọn 1 tiếng).</li><li>Tiếp theo, vào <strong>Security &amp; Privacy</strong> (Bảo mật &amp; Riêng tư).</li><li>Trong tab <strong>General</strong> (Chung), dưới mục <strong>Require password</strong>, chọn \"1 hour\" hoặc một thời gian dài hơn trước khi yêu cầu mật khẩu khi máy tính khóa.</li></ol></li></ul>','BlogContent_Detail_ForAdmin.jpg','menu4',0,'2024-10-14 13:26:53');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-14 17:45:42
