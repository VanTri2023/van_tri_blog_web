-- -----------Create DataBase------------------
DROP DATABASE IF EXISTS DataBlog;
CREATE DATABASE DataBlog;
USE DataBlog;

-- -----------Create Table User ------------------

DROP TABLE IF EXISTS user ;
CREATE TABLE user (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,  -- ID của User, tự động tăng
    username VARCHAR(100) NOT NULL,         -- Tên người dùng (username)
    email VARCHAR(100) NOT NULL UNIQUE,     -- Email (duy nhất)
    `password` VARCHAR(255) NOT NULL,         -- Mật khẩu (hash)
    `role` VARCHAR(50) NOT NULL,              -- Vai trò (admin, user,...)
    created_at DATETIME  -- Thời điểm tạo tài khoản
);
ALTER TABLE DataBlog.user
AUTO_INCREMENT = 1;
-- -----------Create Table Post------------------
DROP TABLE IF EXISTS Post;
CREATE TABLE Post (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,   -- ID của Post, tự động tăng
    name_Blog VARCHAR(255) NOT NULL,         -- Tên Blog
    name_Title VARCHAR(255) NOT NULL,        -- Tiêu đề bài viết
    content_ TEXT NOT NULL,                  -- Nội dung của bài viết
    main_Image VARCHAR(255),                 -- URL hình ảnh chính
    category_Menu VARCHAR(100),              -- Danh mục bài viết
    user_id_ BIGINT NOT NULL,                         -- Khóa ngoại liên kết với bảng User (người tạo bài viết)
    created_at DATETIME  -- Thời điểm tạo bài viết
    -- FOREIGN KEY (user_id_) REFERENCES user(id) ON DELETE CASCADE -- Ràng buộc với bảng User
);
ALTER TABLE DataBlog.Post
AUTO_INCREMENT = 1;

-- -----------Create Table Comment  ------------------
DROP TABLE IF EXISTS Comment  ;
CREATE TABLE Comment (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,   -- ID của Comment, tự động tăng
    content TEXT NOT NULL,                  -- Nội dung của comment
    created_at DATETIME,  -- Thời điểm tạo comment
    post_id BIGINT,                         -- Khóa ngoại liên kết với bảng Post
    user_id_ BIGINT                         -- Khóa ngoại liên kết với bảng User (người bình luận)
    -- FOREIGN KEY (post_id) REFERENCES Post(id) ON DELETE CASCADE,  -- Ràng buộc với bảng Post
    -- FOREIGN KEY (user_id_) REFERENCES user(id) ON DELETE CASCADE   -- Ràng buộc với bảng User
);
ALTER TABLE DataBlog.Comment
AUTO_INCREMENT = 1;
