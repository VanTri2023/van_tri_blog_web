package com.mainprogram;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
